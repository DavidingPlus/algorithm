#include <bits/stdc++.h>
#define maxn 1000010
#define mod 1000000007
using namespace std;
int prime[maxn], vis[maxn], tot, n;
long long ans = 1, tmp, x, y;
int main()
{
    for (int i = 2; i <= maxn; i++)
    {
        if (!vis[i])
            prime[tot++] = i;
        for (int j = 0; j < tot && prime[j] * i < maxn; j++)
        {
            vis[prime[j] * i] = 1;
            if (i % prime[j] == 0)
                break;
        }
    }
    scanf("%d", &n);
    for (int i = 0; prime[i] <= n; i++)
    {
        tmp = 0;
        x = n;
        y = prime[i];
        for (; x; x /= prime[i])
            tmp += x / y;
        ans = (ans * (tmp << 1 | 1) % mod) % mod;
    }
    printf("%d", ans);
}