#include <bits/stdc++.h>
#define maxn 2010
#define INF 1000000000
using namespace std;
int c[maxn], d[maxn];
double k[maxn], f[maxn][maxn][2];
int dis[maxn][maxn];
int n, m, v, e;
int main()
{
    scanf("%d%d%d%d", &n, &m, &v, &e);
    for (int i = 1; i <= n; i++)
        scanf("%d", &c[i]);
    for (int i = 1; i <= n; i++)
        scanf("%d", &d[i]);
    for (int i = 1; i <= n; i++)
        scanf("%lf", &k[i]);
    for (int i = 1; i <= v; i++)
        for (int j = 1; j <= v; j++)
            if (i != j)
                dis[i][j] = dis[j][i] = INF;
    for (int u, v, w; e--;)
    {
        scanf("%d%d%d", &u, &v, &w);
        dis[u][v] = dis[v][u] = min(dis[u][v], w);
    }
    for (int kk = 1; kk <= v; kk++)
        for (int i = 1; i <= v; i++)
            for (int j = 1; j <= v; j++)
                if (dis[i][j] > dis[i][kk] + dis[kk][j])
                    dis[i][j] = dis[i][kk] + dis[kk][j];
    for (int i = 0; i <= n; i++)
        for (int j = 0; j <= m; j++)
            f[i][j][0] = f[i][j][1] = 1e23;
    f[1][0][0] = f[1][1][1] = 0;
    for (int i = 2; i <= n; i++)
        for (int j = 0; j <= m; j++)
        {
            f[i][j][0] = min(
                f[i - 1][j][0] + dis[c[i - 1]][c[i]],
                f[i - 1][j][1] + dis[c[i - 1]][c[i]] * (1 - k[i - 1]) + dis[d[i - 1]][c[i]] * k[i - 1]);
            if (j > 0)
                f[i][j][1] = min(
                    f[i - 1][j - 1][0] + dis[c[i - 1]][c[i]] * (1 - k[i]) + dis[c[i - 1]][d[i]] * k[i],
                    f[i - 1][j - 1][1] + dis[c[i - 1]][c[i]] * (1 - k[i - 1]) * (1 - k[i]) + dis[c[i - 1]][d[i]] * (1 - k[i - 1]) * k[i] + dis[d[i - 1]][c[i]] * k[i - 1] * (1 - k[i]) + dis[d[i - 1]][d[i]] * k[i - 1] * k[i]);
        }
    double ans = f[n][m][0];
    for (int i = 0; i <= m; i++)
        ans = min(ans, min(f[n][i][0], f[n][i][1]));
    printf("%.2lf", ans);
    return 0;
}