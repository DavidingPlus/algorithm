#include<bits/stdc++.h>
using namespace std;
#define maxn 50010
#define G c=getchar()
inline int read()
{
	int x=0,f=1;char G;
	while(c>57||c<48){if(c=='-')f=-1;G;}
	while(c>47&&c<58)x=x*10+c-48,G;
	return x*f;
}
int a[maxn],f[maxn],mn;
typedef pair<int, int> P;
priority_queue<P, vector<P>, greater<P>> Q;
int main()
{
    int n = read();
    for (int i = 0;i<n;i++)
        a[i] = read();
    mn = a[0];
    for (int i = 1; i < mn; i++)
        f[i] = 200000000;
    Q.push(P(0, 0));
    while(!Q.empty())
    {
        P t = Q.top();
        Q.pop();
        if(f[t.second]<t.first)
            continue;
        for (int u = t.second, i = 1; i < n;i++)
            if(f[u]+a[i]<f[(u+a[i])%mn])
                Q.push(P(f[(u + a[i]) % mn] = f[u] + a[i], (u + a[i]) % mn));
    }
    for (int x, m = read(); m--; puts(f[x % mn] <= x ? "TAK" : "NIE"))
        x = read();
}