#include<bits/stdc++.h>
#define maxn 200010
#define mod 1000000007
using namespace std;
typedef long long LL;
#define G c=getchar()
inline int read()
{
	int x=0,f=1;char G;
	while(c>57||c<48){if(c=='-')f=-1;G;}
	while(c>47&&c<58)x=x*10+c-48,G;
	return x*f;
}
LL inv[maxn],fac[maxn],dp[2010];
LL Pow(LL x,LL y)
{
	LL r=1;
	for(;y;y>>=1,x=x*x%mod)if(y&1)r=r*x%mod;
	return r;
}
int C(int n,int m)//C(n,m)
{
	return fac[n+m]*inv[n]%mod*inv[m]%mod;
}
struct poi
{
	int x,y;
}a[2010];
inline bool cmp(const poi &a,const poi &b){return a.x==b.x?a.y>b.y:a.x>b.x;}
int main()
{
	fac[0]=1;inv[0]=Pow(1,mod-2);
	for(int i=1;i<maxn;i++)fac[i]=fac[i-1]*i%mod,inv[i]=Pow(fac[i],mod-2);
	int n=read(),m=read(),k=read();
	for(int i=1;i<=k;i++)
		a[i].x=read(),a[i].y=read();
	a[0].x=a[0].y=1;
	sort(a,a+1+k,cmp);
	for(int i=0;i<=k;i++)
	{
		dp[i]=C(n-a[i].x,m-a[i].y);
		for(int j=0;j<i;j++)
			if(a[i].x<=a[j].x&&a[i].y<=a[j].y)
			{
				(dp[i]-=dp[j]*C(a[j].x-a[i].x,a[j].y-a[i].y)%mod)%=mod;
				if(dp[i]<0)dp[i]+=mod;
			}
	}
	printf("%lld",dp[k]);
	return 0;
}