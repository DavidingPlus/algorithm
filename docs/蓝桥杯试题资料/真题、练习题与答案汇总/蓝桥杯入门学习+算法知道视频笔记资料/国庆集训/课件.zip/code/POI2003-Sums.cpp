#include<bits/stdc++.h>
#define maxn 50010
using namespace std;
typedef long long LL;
#define G c=getchar()
inline int read()
{
	int x=0,f=1;char G;
	while(c>57||c<48){if(c=='-')f=-1;G;}
	while(c>47&&c<58)x=x*10+c-48,G;
	return x*f;
}
int m,i,w,j,st,p,q,n,f[maxn],a[maxn/10],mn=maxn;
bool vis[maxn],cnt;
int main()
{
	n=read();
	for(i=1;i<=n;i++)a[i]=read(),mn=min(mn,a[i]);
	for(i=1;i<mn;i++)f[i]=2000000000;
	for(i=1,w,j;i<=n;i++)
		for(w=a[i]%mn,j=1;j<=2;j++,cnt^=1)
			for(st=0;vis[st]==cnt&&st<mn;st++)
				for(p=st,q=st+w>=mn?st+w-mn:st+w;vis[p]==cnt;vis[p]=cnt^1,p=q,q=q+w>=mn?q+w-mn:q+w)
					if(f[p]+a[i]<f[q])f[q]=f[p]+a[i];
	m=read();
	for(;m--;)
	{
		i=read();
		if(i>=f[i%mn])puts("TAK");
		else puts("NIE");
	}
	return 0;
}