#include<bits/stdc++.h>
#define maxn 2010
using namespace std;
#define G c=getchar()
inline int read()
{
    int x=0,f=1;char G;
    for(;'0'>c||c>'9';G)if(c=='-')f=-1;
    for(;'0'<=c&&c<='9';G)x=10*x+c-48;
    return x*f;
}
int s[maxn][maxn],c[maxn][maxn],D=-1,d[2],g[2],K,T;
int main()
{
    T=read(),K=read();
    for(int i=0;i<=2000;i++)
        s[i][0]=c[i][0]=1;
    for (int i = 1; i <= 2000; i++)
        for (int j = 1; j <= i; j++)
            c[i][j] = (c[i - 1][j - 1] + c[i - 1][j]) % K;
    for(int i=1;i<=2000;i++)
        for(int j=1;j<=2000;j++)
            s[i][j]=s[i-1][j]+s[i][j-1]-s[i-1][j-1]+(c[i][j]==0&&i>=j);
    for(int n,m;T--;)
        n=read(),m=read(),printf("%d\n",s[n][m]);
    return 0;
}