#include <bits/stdc++.h>
using namespace std;
#define maxn 1000010
#define mod 666623333
int n, N, pri[maxn];
typedef long long LL;
bool a[maxn];
LL phi[maxn], K[maxn];
int Eratosthenes_Sieve(int n, int pri[])
{
    for (int i = 2; i * i <= n; i++)
        if (a[i] == 0)
            for (int j = i << 1; j <= n; j += i)
                a[j] = 1;
    int cnt = 0;
    for (int i = 2; i <= n; i++)
        if (!a[i])
            pri[cnt++] = i;
    return cnt;
}
int main()
{
    int cnt = Eratosthenes_Sieve(1000000, pri);
    LL L, R, ans = 0;
    scanf("%lld %lld", &L, &R);
    for (LL i = L; i <= R; i++)
        phi[i - L] = K[i - L] = i;
    for (int i = 0; i < cnt; i++)
        for (LL p = pri[i], j = max(2ll, (L - 1) / p + 1) * p; j <= R; j += p)
        {
            LL x = j - L;
            phi[x] = phi[x] / p * (p - 1);
            for (; K[x] % p == 0;)
                K[x] /= p;
        }
    for (LL i = L; i <= R; (ans += i - phi[i - L]) %= mod, i++)
        if (K[i - L] != 1)
            phi[i - L] = phi[i - L] / K[i - L] * (K[i - L] - 1);
    printf("%lld", ans);
    return 0;
}