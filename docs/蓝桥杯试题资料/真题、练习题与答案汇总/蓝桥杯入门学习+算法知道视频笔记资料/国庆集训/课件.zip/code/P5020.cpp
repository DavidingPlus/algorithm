#include <bits/stdc++.h>
using namespace std;
#define maxv 25010
#define maxn 110
int T, n, a[maxn];
bitset<maxv> v;
int main()
{
    for (scanf("%d", &T); T--;)
    {
        scanf("%d", &n);
        for (int i = 1; i <= n; i++)
            scanf("%d", a + i);
        sort(a + 1, a + 1 + n);
        v.reset();
        v[0] = 1;
        int tmp = 0;
        for (int i = 1; i <= n; i++)
            if (!v[a[i]])
            {
                tmp++;
                for (int w = a[i]; w <= a[n]; w <<= 1)
                    v |= v << w;
            }
        printf("%d\n", tmp);
    }
}