#include <bits/stdc++.h>
using namespace std;
#define add(u, v, w) W[++Si] = w, to[Si] = v, nxt[Si] = idx[u], idx[u] = Si
#define maxn 200010
int to[maxn], idx[maxn], nxt[maxn], W[maxn], Si, du[maxn], in[maxn];
double f[maxn];
queue<int> Q;
int main()
{
    int n, m;
    scanf("%d%d", &n, &m);
    for (int i = 1; i <= m; i++)
    {
        int x, y, z;
        scanf("%d%d%d", &x, &y, &z);
        add(y,x, z);
        du[x]++;
        in[x]++;
    }
    Q.push(n);
    f[n] = 0;
    for (; !Q.empty();)
    {
        int u = Q.front();
        Q.pop();
        for (int i = idx[u]; i; i = nxt[i])
        {
            int v = to[i];
            f[v] += (f[u] + W[i])/ du[v];
            in[v]--;
            if (in[v] == 0)
                Q.push(v);
        }
    }
    printf("%.2lf", f[1]);
}