#include <bits/stdc++.h>
#define maxn 50
using namespace std;
typedef long long LL;
#define G c = getchar()
inline LL read()
{
    LL x = 0, f = 1;
    char G;
    while (c > 57 || c < 48)
    {
        if (c == '-')
            f = -1;
        G;
    }
    while (c > 47 && c < 58)
    {
        x = x * 10 + c - 48;
        G;
    }
    return x * f;
}
LL p[maxn], tot;
LL x, y, w;
LL gcd(LL x, LL y) { return y ? gcd(y, x % y) : x; }
int main()
{
    int n = read();
    y = x = read();
    for (LL i = 2; i * i <= x; i++)
        if (x % i == 0)
            for (p[tot++] = i; x % i == 0;)
                x /= i;
    if (x - 1)
        p[tot++] = x;
    printf("%lld ", tot ? y / p[0] : -1);
    for (int i = 2, j; i <= n; i++)
    {
        x = read();
        w = gcd(x, y);
        int f = 0;
        for (j = 0; j < tot; j++)
            if (w % p[j] == 0)
            {
                f = 1;
                break;
            }
        printf("%lld ", f ? w / p[j] : -1);
    }
    return 0;
}