#include<bits/stdc++.h>
#define maxn 50010
#define maxm 100010
#define mod 1000000007
using namespace std;
typedef long long LL;
#define G c=getchar()
inline int read()
{
	int x=0,f=1;char G;
	while(c>57||c<48){if(c=='-')f=-1;G;}
	while(c>47&&c<58)x=x*10+c-48,G;
	return x*f;
}
#define AE(u,v) to[Si]=v,nxt[Si]=idx[u],idx[u]=Si++
int idx[maxn],nxt[maxm],to[maxm],Si;
int vis[maxn];LL n,x=0;
void dfs(int u)
{
	x++;
	vis[u]=1;
	for(int i=idx[u];i+1;i=nxt[i])if(!vis[to[i]])dfs(to[i]);
}
int main()
{
	memset(idx,-1,sizeof(idx));
	n=read();
	for(int i=1;i<n;i++)
	{
		int u,v;char c;
		scanf("%d %d %c",&u,&v,&c);
		if(c=='b')AE(u,v),AE(v,u);
	}
	LL sum=0;
	for(int i=1;i<=n;i++)
	{
		x=0;
		if(!vis[i])dfs(i);
		sum+=x*(x-1)/2*(n-x)+x*(x-1)*(x-2)/6;
	}
	sum=n*(n-1)*(n-2)/6-sum;sum=sum%mod+mod;
	printf("%lld",sum%mod);
	return 0;
}