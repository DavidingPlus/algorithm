#include <bits/stdc++.h>
using namespace std;
#define add(u, v, w) W[++Si] = w, to[Si] = v, nxt[Si] = idx[u], idx[u] = Si
#define maxn 200010
int to[maxn], idx[maxn], nxt[maxn], W[maxn], Si, du[maxn], in[maxn];
double f[maxn], p[maxn];
queue<int> Q;
int main()
{
    int n, m;
    scanf("%d%d", &n, &m);
    for (int i = 1; i <= m; i++)
    {
        int x, y, z;
        scanf("%d%d%d", &x, &y, &z);
        add(x, y, z);
        du[x]++;
        in[y]++;
    }
    Q.push(1);
    f[1] = 0, p[1] = 1;
    for (; !Q.empty();)
    {
        int u = Q.front();
        Q.pop();
        f[u] /= p[u];
        for (int i = idx[u]; i; i = nxt[i])
        {
            int v = to[i];
            p[v] += p[u] / du[u];
            f[v] += (f[u] + W[i]) * p[u] / du[u];
            in[v]--;
            if (in[v] == 0)
                Q.push(v);
        }
    }
    printf("%.2lf", f[n]);
}