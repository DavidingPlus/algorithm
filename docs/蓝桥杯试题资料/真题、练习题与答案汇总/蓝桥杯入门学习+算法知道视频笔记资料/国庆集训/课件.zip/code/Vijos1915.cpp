#include <bits/stdc++.h>
#define maxn 110
#define pri 4
using namespace std;
typedef long long LL;
int prime[4] = {10007, 10009, 12007, 13001}, a[110][4];
int s[110][2], la[2], anss[110], ans, n, m;
string qwq;
void gcd(LL a, LL b, LL &d, LL &x, LL &y) //ax+by=d
{
    if (!b)
        d = a, x = 1, y = 0;
    else
        gcd(b, a % b, d, y, x), y -= x * (a / b);
}
LL CRT(LL a1, LL p1, LL a2, LL p2)
{
    LL s = a2 - a1, k1, k2, pp = p1 * p2, d;
    gcd(p1, -p2, d, k1, k2);
    s = (s % pp + pp) % pp;
    k1 = (k1 % pp + pp) % pp;
    k1 = k1 * s % pp;
    return (k1 * p1 % pp + a1 % pp) % pp;
}
bool check(LL x)
{
    if (x > m)
        return 0;
    for (int k = 0; k < 4; k++)
    {
        LL tmp = a[n][k];
        for (int i = n - 1; i >= 0; i--)
            tmp = (tmp * x + a[i][k]) % prime[k];
        if (tmp)
            return 0;
    }
    return 1;
}
int main()
{
    scanf("%d%d\n", &n, &m);
    for (int i = 0; i <= n; i++)
    {
        cin >> qwq;
        for (int k = 0; k < pri; k++)
        {
            LL flg = 1, tmp = 0;
            for (int j = 0; j < qwq.length(); j++)
                if (qwq[j] == '-')
                    flg = -1;
                else
                    tmp = (tmp * 10 + qwq[j] - 48) % prime[k];
            a[i][k] = tmp * flg;
        }
    }
    for (int A = 0; A < 2; A++)
        for (int i = 1; i <= prime[A]; i++)
        {
            LL tmp = a[n][A];
            for (int j = n - 1; j >= 0; j--)
                tmp = (tmp * i + a[j][A]) % prime[A];
            if (!tmp)
                s[++la[A]][A] = i;
        }
    int ans = 0;
    for (int I = 1; I <= la[0]; I++)
        for (int J = 1, w; J <= la[1]; J++)
            if (check(w = CRT(s[I][0], prime[0], s[J][1], prime[1])))
                anss[++ans] = w;
    if (!ans)
        puts("0");
    else
    {
        sort(anss + 1, anss + 1 + ans);
        printf("%d\n", ans);
        for (int i = 1; i <= ans; i++)
            printf("%d\n", anss[i]);
    }
    return 0;
}