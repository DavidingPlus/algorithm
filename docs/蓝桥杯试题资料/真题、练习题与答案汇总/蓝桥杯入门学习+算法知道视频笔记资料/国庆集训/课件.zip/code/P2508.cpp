#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
LL r, ans;
LL gcd(LL x, LL y) { return y ? gcd(y, x % y) : x; }
bool check(LL u, LL V)
{
    int v = LL(sqrt(V));
    if (V == v * v)
        return gcd(u, v) == 1;
    return 0;
}
LL calc(LL x)
{
    LL tmp = 0;
    for (LL u = 1; u * u * 2 < x; u++)
        tmp += check(u, x - u * u);
    return tmp;
}
int main()
{
    scanf("%lld", &r);
    for (LL d = 1; d * d <= 2 * r; d++)
        if (2 * r % d == 0)
            ans += calc(2 * r / d) + (d * d == 2 * r ? 0 : calc(d));
    printf("%lld\n", ans * 4 + 4);
    return 0;
}