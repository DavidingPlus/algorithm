#include <bits/stdc++.h>
using namespace std;
#define maxn 8
int a[maxn][maxn], n, m;
vector<string> qwq, v;
void dfs(int x, int y, string s)
{
    char c = a[x][y] + 48;
    s = s + c;
    if (x > n || y > m)
        return;
    if (x == n && y == m)
        qwq.push_back(s);
    dfs(x, y + 1, s);
    dfs(x + 1, y, s);
}
int main()
{
    scanf("%d%d", &n, &m);
    int U = 1 << (m * n), ans = 0;
    for (int S = 0; S < U; S++)
    {
        int tmp = S;
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= m; j++)
                a[i][j] = tmp & 1, tmp >>= 1;
        if(a[2][1]<a[1][2])
            continue;
        if (a[3][1] < a[2][2])
            continue;
        if (a[2][2] < a[1][3])
            continue;
        if (a[3][2] < a[2][3])
            continue;
        printf("%d\n", S);
    }
    printf("%d", ans);
}