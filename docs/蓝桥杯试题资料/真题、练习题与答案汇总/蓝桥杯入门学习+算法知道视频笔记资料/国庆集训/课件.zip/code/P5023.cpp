#include <bits/stdc++.h>
using namespace std;
#define maxn 8
int a[maxn][maxn], n, m;
vector<string> qwq, v;
void dfs(int x, int y, string s)
{
    char c = a[x][y] + 48;
    s = s + c;
    if (x > n || y > m)
        return;
    if (x == n && y == m)
        qwq.push_back(s);
    dfs(x, y+1, s);
    dfs(x+1, y, s);
}
int main()
{
    scanf("%d%d", &n, &m);
    int U = 1 << (m * n), ans = 0;
    for (int S = 0; S < U; S++)
    {
        int tmp = S;
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= m; j++)
                a[i][j] = tmp & 1, tmp >>= 1;
        qwq.clear();
        dfs(1, 1, "");
        v = qwq;
        sort(qwq.begin(), qwq.end());
        if (v != qwq)
            continue;
        ans++;
        for (int i = 1; i <= n; i++, puts(""))
            for (int j = 1;j<=m;j++)
                printf("%d", a[i][j]);
        printf(":%d\n", S);
        puts("");
    }
    printf("%d", ans);
}