#include <bits/stdc++.h>
using namespace std;
#define maxn 1000010
typedef long long LL;
LL a[110][4], mod[4] = {10007, 11003, 12007, 13001};
int b[maxn], n, m;
string qwq;
bool check(LL x)
{
    for (int k = 0; k < 4; k++)
    {
        LL tmp = a[n][k];
        for (int i = n - 1; i >= 0; i--)
            tmp = (tmp * x + a[i][k]) % mod[k];
        if (tmp)
        {
            for (int i = x; i <= m; i += mod[k])
                b[i] = 1;
            return 0;
        }
    }
    return 1;
}
int main()
{
    scanf("%d%d", &n, &m);
    for (int i = 0; i <= n; i++)
    {
        cin >> qwq;
        for (int k = 0; k < 4; k++)
        {
            LL flg = 1, tmp = 0;
            for (int j = 0; j < qwq.length(); j++)
                if (qwq[j] == '-')
                    flg = -1;
                else
                    tmp = (tmp * 10 + qwq[j] - 48) % mod[k];
            a[i][k] = tmp * flg;
        }
    }
    int ans = 0;
    for (int x = 1; x <= m; x++)
        if (!b[x] && check(x))
            ans++;
    printf("%d\n", ans);
    for (int i = 1; i <= m; i++)
        if (!b[i])
            printf("%d\n", i);
}