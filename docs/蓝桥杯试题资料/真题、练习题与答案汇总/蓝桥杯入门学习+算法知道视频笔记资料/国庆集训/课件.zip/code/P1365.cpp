#include <bits/stdc++.h>
#define maxn 1000010
using namespace std;
double p1[maxn], f[maxn];
char qwq[maxn];
int main()
{
    int n;
    scanf("%d", &n);
    cin >> (qwq + 1);
    for (int i = 1; i <= n; i++)
        if (qwq[i] == '?')
        {
            p1[i] = p1[i - 1] / 2 + 0.5;
            f[i] = f[i - 1] + p1[i - 1] + 0.5;
        }
        else if (qwq[i] == 'o')
        {
            p1[i] = p1[i - 1] + 1;
            f[i] = f[i - 1] + 2*p1[i - 1] + 1;
        }
        else
        {
            p1[i] = 0;
            f[i] = f[i - 1];
        }
    printf("%.4lf", f[n]);
}