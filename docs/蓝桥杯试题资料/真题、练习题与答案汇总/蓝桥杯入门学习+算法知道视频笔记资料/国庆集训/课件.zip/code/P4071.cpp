#include <bits/stdc++.h>
#define mod 1000000007
#define maxn 1000010
#define LL long long
using namespace std;
LL fac[maxn], f[maxn];
int t, n, m;
LL Pow(LL a, LL b)
{
    LL ret = 1;
    for (; b; b >>= 1, a = a * a % mod)
        if (b & 1)
            ret = ret * a % mod;
    return ret;
}
int main()
{
    fac[0] = 1;
    for (int i = 1; i <= 1000000; i++)
        fac[i] = fac[i - 1] * i % mod;
    f[0] = 1, f[1] = 0;
    for (int i = 2; i <= 1000000; i++)
        f[i] = (f[i - 1] + f[i - 2]) % mod * (i - 1) % mod;
    for (scanf("%d", &t); t--;)
    {
        scanf("%d%d", &n, &m);
        printf("%lld\n", fac[n] * Pow(fac[m], mod - 2) % mod * Pow(fac[n - m], mod - 2) % mod * f[n - m] % mod);
    }
    return 0;
}